a = [input().split() for _ in range(2)]
num = list(map(int, a[1]))  # value 를 int형 으로 바꿈
my_dict = {key: value for key, value in zip(a[0], num) if key != 'delta' and value != 30}
print(my_dict)