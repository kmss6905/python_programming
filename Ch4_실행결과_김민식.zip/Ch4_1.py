year = int(input())

if year % 12 == 0:
    print("원숭이")
if year % 12 == 1:
    print("닭")
if year % 12 == 2:
    print("개")
if year % 12 == 3:
    print("돼지")
if year % 12 == 4:
    print("쥐")
if year % 12 == 5:
    print("소")
if year % 12 == 6:
    print("호랑이")
if year % 12 == 7:
    print("토끼")
if year % 12 == 8:
    print("용")
if year % 12 == 9:
    print("뱀")
if year % 12 == 10:
    print("말")
if year % 12 == 11:
    print("양")
