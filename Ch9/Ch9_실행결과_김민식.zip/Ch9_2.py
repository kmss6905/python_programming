def scalar_vector_product(scalar, vector):
    print([scalar * i for i in vector])


scalar_v = 5
vector_list = [1, 3, 5, 7, 11, 13]
scalar_vector_product(scalar_v, vector_list)
